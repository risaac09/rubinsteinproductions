# Daily Metabolization

**Date:** {{date:YYYY-MM-DD}}
**Time:** {{time:HH:mm}}

---

## 1. Body Check (30 seconds)

Before you open anything, before you read anything — pause.

**What does your body feel like right now?**

> Contracted / Expanded / Neutral / Buzzing / Heavy / Light / Restless / Still

Write one word or one sentence. Don't analyze it. Just notice.

**Body state:**


---

## 2. What Came In (2 minutes)

What entered your field since the last time you sat here? Not everything — just what's still with you. The things that stuck. The residue.

This could be: a conversation, an article, something you overheard, an idea that arrived while running, a question that surfaced in the shower, a reaction you had that surprised you.

**List what's still with you (max 5):**

-
-
-

---

## 3. What's Alive vs. What's Dead (2 minutes)

Look at your [[Antechamber]]. Look at what you just listed above.

**Alive** = still producing energy, curiosity, tension, or connection. You want to stay with it.
**Dead** = arrived with energy but it's gone now. It was someone else's thought, or it's already been absorbed, or it just doesn't matter anymore.

**Alive:**
-

**Dead (release these):**
-

---

## 4. One Metabolization (1 minute)

Pick ONE alive item. Don't pick the biggest — pick the one with the most charge right now.

**What does this idea connect to?** Not what is it — what is it *with*? What does it sit next to in your thinking?

**Connection:**


**If this wants to move somewhere, where?** (Link to a Map or leave blank if it's not ready.)

---

## End

Close this note. Don't review it. Don't optimize it. The practice is the processing — the note is just the residue of the practice.

Tomorrow, create a new daily note in the `Journal/` folder (name it with today's date, e.g., `2026-04-03`). Don't look back at yesterday's unless something from it is still alive in your [[Antechamber]].
