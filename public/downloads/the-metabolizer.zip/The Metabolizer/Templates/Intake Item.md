# {{title}}

**Captured:** {{date:YYYY-MM-DD}}
**Source:** 
**Body signal:** Contracted / Expanded / Curious / Neutral

---

## The Signal

> What is this? One to three sentences. Don't explain — just capture what's alive about it.



---

## Connections (if any)

> Does this connect to anything already in your Maps? Link it. If not, leave blank.



---

## Status

- [ ] Ready to metabolize
- [ ] Still cooking
- [ ] Ready to release
