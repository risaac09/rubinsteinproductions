# Demo Weekly Threshold

**Week of:** 2026-03-22

---

## The One Question

**What shifted this week?**

I stopped calling it leadership. The thing I've been doing at work — absorbing everyone else's anxiety so the team can keep functioning — I have been calling that leadership for four years. This week I noticed the body cost, named it out loud to my partner, and the name changed. It's not leadership. It's a trained response that I've dressed up as competence.

The shift isn't knowing the pattern. I've known the pattern. The shift is that I'm not willing to keep paying for it.

---

## Antechamber Audit

- [x] 4–5: Healthy range. Keep processing.

## What Decayed / Released

- The board chair email I re-read four times (it was never mine to carry)
- A note from early March about "building emotional infrastructure" — died quietly, didn't return
- The patient trust moment — metabolized and released

## Building

Something is assembling across Observations, Questions, and Practice about the difference between **absorbing** and **holding**. Three entries now point at it. This might become an essay, or it might just change how I show up in Monday's meeting. Not forcing it.

## Energy

**Energy:** 7/10
