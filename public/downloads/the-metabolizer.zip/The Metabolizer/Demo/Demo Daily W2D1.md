# Demo Daily — Week 2, Day 1

**Date:** 2026-03-23
**Time:** 06:48

---

## 1. Body Check

**Body state:** Open chest. Low steady charge. Belly warm. First morning in a week I haven't woken contracted. Something moved over the weekend.

---

## 2. What Came In

- Weekend threshold entry: I finally said "I am carrying more than is mine" out loud, to my partner
- Read something about grief as a physical practice — body metabolizing what the mind can't yet
- A former colleague reached out. I felt both warmth and a small refusal.
- The clinic looked different walking in today

---

## 3. Alive vs. Dead

**Alive:**
- The grief-as-physical-practice line. Wants to sit next to the shoulder-blade contraction thing.
- The refusal I felt with the colleague. Small but specific.

**Dead:**
- The "clinic looked different" perception — it's true but it's a consequence, not a signal.

---

## 4. One Metabolization

Picking: **refusal with the colleague.**

**What does this connect to?** It's not about her. It's about: *what I'm saying no to without saying no to it*. Related to the weekend threshold. My body is starting to refuse things before my mouth does.

**Where does this want to go?** → [[Demo Practice]] as emerging — *letting the body lead the no*.

---

## End
