# Demo Practice

---

## Active Practices

**Morning body check before email.**
14 days in. The most reliable input to the whole system. Still asks something of me — I still find words I've never used for what's happening.

**Weekly threshold on Sunday night.**
One paragraph. The question stays the same; the answer is always different.

**Three-breath pause before responding in meetings.**
Not a Metabolizer prompt — something I started on my own after W1D3. Changes what comes out of my mouth.

---

## Dormant Practices

**Morning journaling (long-form).**
Did it for years. Became a performance. Replaced by the daily metabolization — shorter, asks more.

**Reading one article per day and clipping to Obsidian.**
This was the old system. Produced accumulation. Dead practice. No plans to revive.

---

## Emerging Practices

**Letting the body lead the no.**
Just started. Noticing moments where I felt a small refusal before my mouth caught up. Interested in whether this becomes a reliable signal or just a mood. *(from W2D1)*

**Naming what I'm absorbing out loud to my partner.**
Only done it once. It moved something. Worth trying again without turning it into a ritual.
