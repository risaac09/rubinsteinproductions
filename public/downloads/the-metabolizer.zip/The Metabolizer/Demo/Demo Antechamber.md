# Demo Antechamber

**Maximum capacity: 7 items. Currently: 5.**

---

## Current Intake

- [ ] The thing my CFO said in the hallway about "managing the narrative" — I contracted. Why.
- [ ] Podcast line: "Most organizations are over-managed and under-led." Bothered by how easy it sounds.
- [ ] Noticed I am drafting the same email to Dr. M three times and not sending any of them
- [ ] Article on burnout — doctors don't leave jobs, they leave their relationship to their own judgment *(3 days old — still cooking)*
- [ ] The feeling in Monday's leadership meeting when J got interrupted and nobody noticed *(5 days — close to decay)*

---

## Processed Last Week (archived trail)

> Kept visible for the demo. Normally these would be removed after metabolization.

- ~~"The patient-centered care language is eating its own meaning"~~ → [[Demo Observations]] as pattern
- ~~"Why do I resist the quarterly review every time"~~ → [[Demo Questions]]
- ~~Team member offered unsolicited feedback — I contracted then expanded~~ → [[Demo Practice]] as emerging practice
- ~~"Connection between burnout framing and moral injury language"~~ → [[Demo Connections]]
- ~~Email from the board chair that I read four times~~ → released (wasn't mine to carry)
