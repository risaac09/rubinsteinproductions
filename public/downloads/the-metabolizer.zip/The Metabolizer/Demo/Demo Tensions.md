# Demo Tensions

---

## Active Tensions

**Being the stable presence AND refusing to absorb more than is mine.**
The team relies on my steadiness. If I stop absorbing, some of that anxiety will have to land somewhere — possibly on them. The cost of picking "refuse to absorb" is that people I care about have to carry their own weight earlier than they're ready to. The cost of picking "be the stable presence" is that I become unsustainable and eventually leave, which is worse for them than the short-term discomfort. Holding both.

**Saying the honest thing to Dr. M AND staying in the working relationship.**
Third draft of an email now. The honest version ends a collaboration that has produced 3 years of good clinical work. The diplomatic version preserves the relationship but the thing I want to say keeps resurfacing as a need. Default pole: diplomacy. Worth sitting with.

**Moving on the absorbing/holding insight AND letting it keep cooking.**
I want to *do something* with this — tell my team, restructure Monday's meeting, write the essay. The Metabolizer's whole premise is that premature action is a way of discharging the discomfort before it teaches you anything. Holding.

---

## Resolved

None yet. That's honest.
