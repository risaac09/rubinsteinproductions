# Demo Observations

---

## Active Observations

**Patient-centered care language is eating its own meaning.**
Every organization uses it. No organization can tell you what they'd do differently if they took it out of the vocabulary. When the language becomes universal, it stops marking a distinction. *(from W1D2)*

**Institutions remember policies, not purposes.**
The clinic has a written protocol for something we started doing in 2019 for a specific reason. Nobody on the team knows the reason. We know the protocol. Policies are what survives purpose-erosion. *(linked to [[Demo Questions]])*

**J's interruption in Monday leadership → the meeting absorbed it as normal.**
The pattern: a thing happens, the room doesn't acknowledge it, the non-acknowledgment becomes the new baseline. This is how cultures drift. Not through decisions — through the things the room agrees to not notice.

---

## Patterns

**Purpose-erosion vs. policy-accretion.**
"Patient-centered care" + "institutions remember policies, not purposes" + J's interruption all point at the same structural pattern: **organizations accumulate forms and lose substance.** The forms are easier to protect than the substance. Worth watching for this in my own team.
