# Demo Connections

---

## Active Connections

**Burnout framing + moral injury language = the body keeps the score of the institutional compromise.**
"Burnout" locates the problem in the individual (you need self-care). "Moral injury" locates it in the structure (you were asked to do something against your values). My team uses "burnout." Their bodies are telling a moral injury story. The language gap is the issue.

**Grief as physical practice + the between-shoulder-blades contraction = my body is grieving something I haven't named yet.**
The three-morning contraction showed up the same week I stopped pretending the absorbing-as-leadership thing was sustainable. Something is ending. The body is ahead of the mind. *(W2D1)*

**Managing the narrative (CFO hallway) + J's un-noticed interruption = the same thing from two altitudes.**
Executive: actively shaping what gets said. Meeting floor: passively deciding what doesn't get noticed. Both are the same function: the organization's immune system deciding which signals to absorb vs. amplify. I'm part of that immune system. Uncomfortable.

---

## Threads

**The absorbing/holding thread.**
Three connections + two questions + one observation are now all pointing at this: the difference between **absorbing** a thing (taking it into your body, carrying the cost) and **holding** it (witnessing it, not collapsing the space it needs to exist in). This is becoming a frame. Might become an essay. Might become a shift in how I run Monday meetings. Don't know yet. Letting it gather.
