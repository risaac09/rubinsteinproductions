# Demo Daily — Week 1, Day 3

**Date:** 2026-03-18
**Time:** 07:12

---

## 1. Body Check

**Body state:** Jaw tight. Breath high. Belly fine. A specific small contraction between my shoulder blades I've felt three mornings this week.

---

## 2. What Came In

- A patient family said "we trust you" and I noticed I didn't fully believe them
- Read a paragraph about institutional memory vs. institutional habit
- J cried in the break room. I asked if she wanted to talk. She said no. I let it be.
- The thought I keep having while driving home: "I am the most tired senior person on my team and nobody says it out loud"

---

## 3. Alive vs. Dead

**Alive:**
- The tired-senior-person thought. That's been buzzing for weeks.
- Institutional memory vs. habit distinction
- The between-shoulder-blades contraction — same three mornings

**Dead:**
- Patient trust moment — it arrived with charge, but I've already absorbed it. It told me something and moved on.

---

## 4. One Metabolization

Picking: **tired-senior-person thought.**

**What does this connect to?** It sits next to the CFO hallway comment about "managing the narrative." Both are about being the person who absorbs the anxiety so the team can function. I'm not sure if that's leadership or if it's a trained helplessness I'm calling leadership.

**Where does this want to go?** → [[Demo Questions]] as a live question. Not ready for [[Demo Observations]] yet — it's still asking me something.

---

## End
