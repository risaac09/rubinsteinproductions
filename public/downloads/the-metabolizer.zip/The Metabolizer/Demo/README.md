# Demo

**Two weeks of a real practice, by a fictional user.**

These files show what the Metabolizer looks like after 14 days of honest use. Everything here is an example — realistic content, same formats as the templates, populated Maps.

The persona: a clinic director in her mid-40s who reads widely, manages a team of 12, and has been failing at PKM for three years. She bought the vault because she was tired of her Obsidian vault feeling like a monument to her own avoidance.

Use these to see:
- What "one line per intake item" actually looks like
- How items move from Antechamber → Daily Practice → Map
- What a Map entry sounds like (vs. a filed note)
- What a weekly threshold sounds like when the week was mundane
- What friction log entries catch

**Don't copy the content.** Copy the *shape*.

When you're oriented, delete this folder.

---

## Files

- [[Demo Antechamber]] — 5 active items at various lifecycle stages
- [[Demo Daily W1D3]] — a mid-week daily practice
- [[Demo Daily W2D1]] — a Monday daily practice after a threshold weekend
- [[Demo Weekly Threshold]] — Week 2 threshold entry
- [[Demo Observations]], [[Demo Questions]], [[Demo Connections]], [[Demo Tensions]], [[Demo Practice]] — populated Maps
- [[Demo Friction Log]] — catching the system becoming avoidance
