# Demo Questions

---

## Active Questions

**Am I leading or am I absorbing?**
The most charged question in the vault right now. I've been calling it leadership for 4 years. It might be trained helplessness wearing a competent face. Related to the tired-senior-person thought (W1D3) and the weekend threshold.

**Why do I resist the quarterly review every single time?**
Not the review itself — the *feeling before* the review. It's the same contraction every quarter. What am I bracing for that isn't actually happening?

**What is the clinic's original purpose, and who still remembers it?**
Prompted by the institutional-memory observation. Might be worth asking the two people who've been there longest — not in a meeting, informally.

---

## Resolved

**→ "Should I respond to the board chair's email?"**
Resolved into: *this isn't mine to carry.* Released the email from Antechamber. The question transformed from "what do I say" to "why am I holding this at all."
