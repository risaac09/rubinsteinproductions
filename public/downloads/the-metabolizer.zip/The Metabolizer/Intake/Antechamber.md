# Antechamber

**Maximum capacity: 7 items.**
When this is full, process before you add.

---

## How to Use

When something arrives — an idea, an article, a conversation fragment, a question that won't leave — add it below as a bullet. One line. Don't elaborate yet. Just capture the signal.

When you hit 7, stop. Open your [[Daily Metabolization|daily practice]] and process at least 2 items before adding anything new.

**Processing means one of three things:**
1. **Metabolize:** Write about it. Let it connect to something. Move the result to the relevant Map ([[Observations]], [[Questions]], [[Connections]], [[Tensions]], or [[Practice]]).
2. **Hold:** It's not ready. Leave it. But it starts decaying — if it's still here in 7 days, the [[Decay Review]] will surface it.
3. **Release:** It's not yours. Delete it. No guilt.

---

## Current Intake

> Delete this example and start fresh. It's here so you can see one full metabolization arc before you delete.

- [ ] **Example (worked):** "That line from the podcast about how organizations forget their own origin stories" *(arrived Mon · sat with it Wed · Thu connected to a note about family systems · metabolized into [[Observations]] as the pattern "Institutions remember policies, not purposes" · released original intake line Thu night)*

---

## Rules

1. **No more than 7.** This is not arbitrary — it's a forcing function. Your attention is finite. Honor that.
2. **One line per item.** If you need more than one line, you're already processing. Move it to a Map.
3. **Check the body.** Before adding something, pause. Does this item produce curiosity, contraction, or nothing? If nothing — it's probably noise. Don't add it.
4. **Date not required.** The decay system tracks when notes were last modified. You don't need to timestamp manually.
