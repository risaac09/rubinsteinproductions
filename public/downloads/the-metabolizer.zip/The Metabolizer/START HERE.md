# The Metabolizer

**An Obsidian vault for people who are tired of accumulating and ready to start digesting.**

---

## What This Is

This is not a second brain. It's a digestive system.

Most knowledge management tools are built for capture — get the idea down, tag it, link it, file it. The problem isn't capture. You're already good at that. The problem is that captured information sits there. It doesn't become anything. It accumulates weight without producing clarity.

The Metabolizer is built on a different premise: **information is not an object to be stored. It's an event to be processed.** Like food, it either gets metabolized — broken down into something your system can actually use — or it sits undigested, taking up space and energy.

This vault has:
- **Finite intake capacity.** You can't dump everything in. You have to choose.
- **Built-in decay.** Notes that aren't touched get surfaced for a decision: process or release.
- **A daily practice.** Five minutes. What came in. What's alive. What's dead.
- **Friction by design.** The constraints aren't bugs. They're the product.

---

## New Here? Start With Onboarding

Open `Onboarding/README.md`. Seven days, one short note per day. After Day 7, delete the folder. The onboarding practices the decay principle.

If you want to see what the vault looks like after two weeks of real use, open the `Demo/` folder. When you're oriented, delete it.

---

## How to Use This Vault

### 1. Start with the Intake
Open [[Antechamber]]. This is where new information enters. Maximum 7 items at a time. When it's full, you process before you add.

### 2. Run the Daily Practice
Every day (or whenever you sit down), open [[Daily Metabolization]]. Five minutes. Four prompts. Don't skip the body check.

### 3. Let Things Decay
Once a week, open [[Decay Review]]. Notes older than 7 days that haven't been touched will be listed. For each one: metabolize it (move it into a Map) or release it (delete or archive). No guilt.

### 4. Use the Maps
The Maps folder contains 5 starting maps: [[Observations]], [[Questions]], [[Connections]], [[Tensions]], and [[Practice]]. These are living documents — they grow as you metabolize. Don't create new maps until the existing ones feel full. Resist the urge to over-organize.

### 5. Weekly Threshold Check
Every week, open [[Weekly Threshold]]. One question: what shifted? Not what happened — what changed in how you see things.

### 6. Friction Log (the meta-practice)
Whenever you catch the system becoming the avoidance, name it in [[Friction Log]]. One line. This is the only file that watches the vault itself.

### 7. Body Vocabulary
If the body check feels impossible, open [[Body Vocabulary]]. It's a word-finding tool, not a checklist.

---

## Philosophy

Read [[Philosophy]] if you want to understand why this vault works the way it does. It's optional — the system works without the theory.

---

## Requirements

- Obsidian (free, any platform)
- Dataview plugin (free, community plugins) — pre-configured in this vault, but you may need to enable it:
  1. Open Settings → Community Plugins → Turn on community plugins
  2. Browse → search "Dataview" → Install → Enable
- That's it. No paid plugins, no sync required.

## Using Templates

This vault includes templates for daily practice and intake items. To use them:
1. Create a new note in `Journal/` (for daily practice) or `Intake/` (for new items)
2. Open the command palette (Ctrl/Cmd + P) → "Templates: Insert template"
3. Select `Daily Metabolization`, `Intake Item`, or `Threshold Entry`
4. The date and time fields fill in automatically

---

## One Rule

**Don't optimize the system. Use the system.**

The moment you start spending more time adjusting the vault than thinking inside it, the vault has become the avoidance. Notice that. Come back to the practice.

---

*Built by Threshold Tools.*
*No newsletter. No community. No course. Just the vault.*
