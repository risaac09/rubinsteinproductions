# Philosophy

---

## Why Most Knowledge Systems Fail

They fail because they're built on a category error.

The dominant model treats information as **substance** — something that exists independently, can be captured, stored, retrieved, and owned. Notes are objects. Knowledge is a collection of objects. A "second brain" is a warehouse.

This model works for reference material. It fails for thinking.

Thinking is not a substance. It's a **process**. It happens in the encounter between you and an idea, between one idea and another, in a specific moment that won't repeat. When you reduce that encounter to a note and file it, you've preserved the artifact but lost the event.

Most people's vaults are full of artifacts from events they never fully attended.

---

## The Metabolization Model

This vault is built on a different model: **information as something to be metabolized, not stored.**

The metaphor is biological. Your body doesn't store food — it metabolizes it. It breaks down what comes in, extracts what it can use, and expels what it can't. The organ that does the heaviest work here is the liver: it doesn't judge input. It processes. It transforms.

Your information system should work the same way:

1. **Intake is finite.** You can't eat continuously. You shouldn't intake information continuously either. This vault has a cap: 7 items in the antechamber at any time. When it's full, you process before you add.

2. **Processing requires attention.** Metabolization is not filing. Filing feels like relief — you put it somewhere and move on. Metabolization feels like *discomfort and then clarity* — you sit with the idea long enough for it to change something in how you think. The daily practice is designed to create a container for this.

3. **What isn't metabolized should decay.** Your body doesn't store every molecule of food forever. Unprocessed information should have a half-life. In this vault, notes that sit untouched for 7 days get surfaced for a decision. You either process them or let them go. No infinite archive. No "I'll get to it later" pile.

4. **The output is not notes — it's changed thinking.** The measure of this system is not how many notes you have. It's whether your thinking is different than it was last week. The weekly threshold check exists to make this visible.

---

## On Friction

This vault is deliberately harder to use than most Obsidian setups. That's intentional.

Convenience is not neutral. Every piece of friction you remove from information intake is a piece of metabolization you skip. One-click capture, frictionless save, automatic import — these are tools for accumulation, not digestion.

The Metabolizer reintroduces specific friction at specific points:

- **Intake friction:** You can't add more than 7 items. This forces triage — you have to decide what's worth your limited processing capacity.
- **Processing friction:** The daily practice asks you to notice your body's response before you engage your mind. This is slower than just typing. That's the point.
- **Retention friction:** Decay is automatic. If you don't attend to something, it surfaces for release. This prevents the vault from becoming a monument to your intellectual life rather than the living tissue of it.

---

## On Minimalism

This vault ships with 5 maps of content. Not 50. Not a pre-built ontology of every possible domain.

Start with the maps that are here. Let them fill up. Only create new maps when an existing one is clearly holding two different things that need to separate. Premature structure is premature optimization — it makes the system feel complete before the thinking has had a chance to tell you what it actually needs.

The best vault structure is the one that emerged from your actual thinking, not the one you designed before you started.

---

*"Metabolize, don't file."*
