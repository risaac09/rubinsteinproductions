# Body Vocabulary

**A reference for the body check. Not a checklist.**

---

## Why This Exists

The body check is the hardest prompt in the daily practice. Most people skip it. The reason is not resistance — it's **vocabulary**. We were trained to describe thoughts, not sensations. When asked "what does your body feel like?", most people default to *"fine"* or *"tired"* and move on.

This is a vocabulary expander. When you can't find the word, scan the list. When you find the word that lands, that's the body check.

Don't use this as a checklist. Don't try to notice every quality. Notice *one*.

---

## Qualities

### Temperature
warm · cool · hot · cold · flushed · feverish · chilled · clammy · even · damp

### Density
heavy · light · dense · porous · thick · thin · solid · hollow · leaden · airy

### Movement
still · buzzing · fluttering · pulsing · churning · spiraling · trembling · rocking · settled · agitated

### Edges
contracted · expanded · tight · loose · held · released · braced · yielding · sharp · blurred

### Breath
shallow · deep · caught · free · high · low · suspended · ragged · smooth · held

### Texture
smooth · rough · grainy · silky · prickly · tender · taut · soft · brittle · warm-soft

### Direction
rising · falling · pulled down · lifting · pressing out · pressing in · scattered · centered · forward · withdrawn

### Charge
buzzing · neutral · charged · flat · electric · dull · alert · foggy · sharp · muffled

---

## Composite States (examples)

These are not categories to fit yourself into. They're examples of how the qualities combine.

- **Threshold alertness** — chest open, breath high, belly taut, slight buzz in hands. *You're about to say something that matters.*
- **Productive contraction** — shoulders forward, jaw set, breath shallow, warm. *There's something real here that you don't want to look at.*
- **Empty calm** — even temperature, slow breath, low charge. *Neutral. Could tip either direction.*
- **Avoidance stillness** — held breath, flat charge, blurred edges. *You're about to open a distraction.*
- **Metabolizing** — warm belly, settled breath, porous edges. *Something is digesting.*
- **Residue** — faint contraction in one specific place (throat, gut, chest). *An unprocessed thing from earlier is still with you.*

---

## The Rule

**One word is enough.** Pick the quality that has the most charge. Don't describe your whole body — describe the loudest part.

If you can't find a word, write: *"I can't find a word."* That is a valid body check. It tells you something.

---

## When to Expand Your Vocabulary

Notice which words you return to. If you write "contracted" every day for a week, you're either genuinely contracted or you've found a shortcut. Force yourself to find a second word.

Words you never use are often the ones you need. Scan the list for a quality you've never named in yourself and notice if it's there.

---

*The nervous system knows what matters before the intellect does. Give the nervous system language.*
