# Friction Log

**The one meta-practice: notice when the system becomes the avoidance.**

---

## Why This File Exists

The Metabolizer is built on deliberate friction. Friction done right produces processing. Friction done wrong produces performance — you start *using the system* in order to not do the thing the system is supposed to help you do.

This file catches that.

Every honest knowledge system eventually becomes a hiding place. The question is whether you notice when it happens. This log is where you notice.

---

## How to Use

Open this file whenever you catch yourself in one of these moments. Write one line. Don't explain. Don't justify. Just name it.

Run it through three prompts:

1. **Where did I almost add instead of process?**
   (You reached for capture when what was needed was digestion.)

2. **What did I extend when I should have released?**
   (You touched a note to reset the decay clock because letting it go felt like losing something.)

3. **When did I open the vault to avoid something else?**
   (You came here to look busy thinking instead of doing the thing that scares you.)

---

## Entries

> One line per entry. Date optional — the file's modification history is your record.

-

---

## Pattern Check (monthly)

Read back through your entries. Do you see the same avoidance in different outfits? Name the pattern here:

**Patterns:**
-

---

## The Rule

If this file has more entries this month than last month, something is working — you're getting more honest.

If this file is empty for three months, one of two things is true: you've integrated the meta-practice, or you've stopped looking. Assume it's the second one. Look again.

---

*"Don't optimize the system. Use the system."*
