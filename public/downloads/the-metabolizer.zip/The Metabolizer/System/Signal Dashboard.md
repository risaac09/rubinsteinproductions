# Signal Dashboard

**What's alive in this vault right now.**

Check this when you feel lost in your own thinking. Not daily. Not as a ritual. As an orientation tool — then close it.

A dashboard in a vault built against dashboards is a paradox. This one earns its place by showing you only three things: what's in, what's decaying, what's recent. That's it. If you want more data, that's the pull to watch.

---

## 1. In the Antechamber

```dataview
LIST
FROM "Intake"
WHERE file.name != "Antechamber"
SORT file.mtime DESC
```

---

## 2. Decaying (7+ Days Untouched)

> Metabolize, release, or extend. Extension is often avoidance wearing a mask.

```dataview
TABLE file.mtime AS "Last Touched", (date(now) - file.mtime).days AS "Days Dormant"
FROM "Intake"
WHERE file.name != "Antechamber"
WHERE (date(now) - file.mtime).days >= 7
SORT file.mtime ASC
```

---

## 3. Recently Metabolized (Last 14 Days)

> Your active thinking surface. What's moved recently across Maps and Journal.

```dataview
TABLE file.mtime AS "Last Touched", file.folder AS "Location"
FROM ""
WHERE (date(now) - file.mtime).days <= 14
WHERE file.folder != "Templates" AND file.folder != "System" AND file.folder != "Brand"
WHERE file.name != "Signal Dashboard" AND file.name != "START HERE"
SORT file.mtime DESC
LIMIT 10
```

---

## Vital Signs (check honestly, not frequently)

| Metric | Healthy Range |
|---|---|
| Antechamber items | 0–7 |
| Daily practices this week | 3–7 |
| Items decayed this week | 1–4 (this is normal, not failure) |
| Time on system vs. thinking | <20% on system |

If you're checking this dashboard more than once a week, it has become the avoidance. Log it in the [[Friction Log]] and close this file.
