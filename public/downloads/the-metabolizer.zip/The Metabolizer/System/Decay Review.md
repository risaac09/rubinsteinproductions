# Decay Review

**Run this weekly.** Sunday or Monday — whenever you do your [[Weekly Threshold|threshold check]].

---

## How Decay Works

Every note in your [[Antechamber]] has a clock running. If a note hasn't been modified in 7 days, it appears in the query below. This is not punishment — it's metabolic honesty. Information you haven't attended to in a week is information your system is not currently able to process.

**For each decayed item, choose one:**

1. **Metabolize now.** Open it, sit with it, write about it, connect it to a Map. Then remove it from the Antechamber.
2. **Release.** Delete it. It's not yours right now. If it matters, it will return.
3. **Extend.** Touch it (add a note, a question, a "still cooking" comment) to reset the clock. Use this sparingly — extending is often avoidance wearing a responsible mask.

---

## Decayed Items

> **Requires the Dataview plugin.**
> This query surfaces any file in the Intake folder that hasn't been modified in the last 7 days.

```dataview
TABLE file.mtime AS "Last Touched", (date(now) - file.mtime).days AS "Days Dormant"
FROM "Intake"
WHERE file.name != "Antechamber"
WHERE (date(now) - file.mtime).days >= 7
SORT file.mtime ASC
```

---

## Vault-Wide Decay Scan

> Optional: surface dormant notes across the entire vault, not just Intake.
> Uncomment the query below if you want full-vault decay visibility.

<!--
```dataview
TABLE file.mtime AS "Last Touched", (date(now) - file.mtime).days AS "Days Dormant"
FROM ""
WHERE file.name != "Antechamber" AND file.name != "Decay Review" AND file.name != "START HERE" AND file.name != "Philosophy" AND file.name != "Signal Dashboard"
WHERE (date(now) - file.mtime).days >= 21
SORT file.mtime ASC
LIMIT 20
```
-->

---

## After the Review

Update your [[Weekly Threshold]] with what you released. Then close this note.

The goal is not zero decay. The goal is an honest relationship with what you can actually process right now.
