# Observations

**Structural observations about how things work — systems, patterns, dynamics.**

This is for the things you notice about how the world is organized. Not opinions. Not reactions. Observations — the kind that make you go "huh, that's how it actually works."

These might come from: work, reading, conversations, watching systems fail or succeed, noticing what's rewarded vs. what's valuable.

---

## Active Observations

> Add metabolized observations here. Link to other Maps when connections emerge.



---

## Patterns

> When you notice the same observation appearing in multiple contexts, it's becoming a pattern. Promote it here.


