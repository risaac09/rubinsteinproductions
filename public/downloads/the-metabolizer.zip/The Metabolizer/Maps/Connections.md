# Connections

**Where two things that seemed separate turned out to be the same thing.**

This map tracks the moments of integration — when an idea from one domain connects to an idea from another and produces something neither could produce alone.

These are the most valuable outputs of a metabolization practice. They can't be planned. They can only be noticed.

---

## Active Connections

> Format: **[Thing A] + [Thing B] = [What emerged]**
> Link to the original notes or Maps when possible.



---

## Threads

> When multiple connections start pointing in the same direction, a thread is forming. This might become an essay, a project, a conversation, or a new Map.


