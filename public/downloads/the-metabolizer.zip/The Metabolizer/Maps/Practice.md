# Practice

**What you're actually doing — the embodied, daily, concrete practices that shape how you process.**

This is not a habit tracker. It's a place to notice what practices are alive (producing change) and which have become automatic (producing nothing).

A practice is alive when it still asks something of you. A practice is dead when you can do it without being changed by it.

---

## Active Practices

> What practices are you currently engaged in? Not aspirational — actual. What did you do this week?



---

## Dormant Practices

> Practices you used to do that dropped away. Not failures — seasons. They may return.



---

## Emerging Practices

> Things you're doing that haven't become practices yet — experiments, one-offs, impulses that keep recurring.


