# Tensions

**Things that pull in two directions at once — and shouldn't be resolved too quickly.**

Tensions are not problems to solve. They're polarities to hold. Most interesting thinking lives in the space between two true things that seem to contradict each other.

Examples: depth vs. breadth, honesty vs. diplomacy, structure vs. emergence, action vs. reflection, individual vs. system.

---

## Active Tensions

> Describe the tension. Name both poles. Don't pick a side — sit with it.



---

## Resolved Tensions

> Sometimes a tension resolves — not by one side winning, but by finding a frame that holds both. When that happens, move it here and describe the resolution.


