# Questions

**The questions you're actually living inside — not trivia, not tasks, not things Google can answer.**

A real question changes how you see. It doesn't resolve quickly. It's uncomfortable to hold. It reorganizes what you pay attention to.

This map is for questions that are doing work on you, not questions you're working on.

---

## Active Questions

> Add questions here as they emerge from daily practice. Don't rush to answer them.



---

## Resolved

> When a question transforms — not just gets answered, but shifts into a different question or resolves into an observation — move it here with a note about what shifted.


