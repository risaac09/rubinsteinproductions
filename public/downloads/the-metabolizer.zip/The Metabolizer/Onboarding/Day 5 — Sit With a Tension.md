# Day 5 — Sit With a Tension

Most people try to resolve tensions. The Metabolizer asks you to *hold* them.

A tension is two things that are both true and pull in opposite directions. Depth vs. breadth. Honesty vs. diplomacy. Structure vs. emergence. The interesting thinking lives in the pull, not in picking a side.

Today you practice sitting.

## The Action

Look at the remaining items in your [[Antechamber]]. Look at your life right now — work, relationships, creative practice, health.

Name one tension you're currently living inside. One sentence. Both poles.

Example format:
> *I want to say the honest thing AND I want to stay in relationship with this person.*
> *I want to deepen the project I have AND I want to follow the new thing that just arrived.*

Add it to [[Tensions]].

Then — and this is the practice — **don't solve it.** Write one sentence below it describing what it would cost to pick either side. Leave both costs on the page.

## The Reflection

**Which pole do you habitually collapse toward?** Most people have a default side they always pick. Name yours.

**My default:**

---

*Collapsing the tension early is how you stop thinking. Holding it is how thinking actually happens.*

*Tomorrow: the first decay review.*
