# Day 7 — First Threshold

One week in.

Open [[Weekly Threshold]]. Answer the one question honestly:

**What shifted?**

Not what you accomplished. Not how many notes you took. What *changed* — in how you see, what you notice, what you're willing to say, what you're no longer willing to carry.

A threshold is a door you walk through and can't walk back through the same way. This week, the threshold might be small. That's fine. Small is honest.

## The Action

Write one paragraph in [[Weekly Threshold]]. Set an energy score (1–10) and release anything worth releasing.

Then come back here.

## The Reflection (final)

**What was the hardest prompt this week?**

**What was the easiest, and did it become automatic?**

Automatic = dead. If a prompt already feels routine after 7 days, it has stopped asking something of you. Notice that.

---

## Graduate

Delete or archive the `/Onboarding/` folder now.

You have the practice. The scaffolding is no longer yours to carry.

From here forward:
- Daily practice in `/Journal/`
- Weekly threshold on Sundays
- Decay review weekly
- Friction log whenever you catch the system becoming the avoidance
- Maps grow when they grow, not before

The vault is now yours.

---

*Metabolize, don't file.*
