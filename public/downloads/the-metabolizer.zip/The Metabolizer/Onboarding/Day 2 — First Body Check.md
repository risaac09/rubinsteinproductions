# Day 2 — First Body Check

The body check is the most-skipped prompt in this system. That's because it's the hardest one and the one you were never trained to do.

You were taught to describe thoughts. You were not taught to describe sensations. "Fine" and "tired" are defaults, not answers.

Today you find a word.

## The Action

Before you open anything — no notes, no apps, not even this page again after you read it — **close your eyes for 30 seconds.**

Scan your body top to bottom. Chest, belly, jaw, shoulders, hands.

Find the loudest part. Not the biggest sensation — the one that wants attention.

Open your eyes. Open [[Body Vocabulary]]. Find the word.

Write it below.

**My body right now:**

## The Reflection

**Was the word easy or hard to find?**

If easy: notice if you reached for a familiar default (contracted / buzzing / tired). Force a second word.

If hard: that's honest. You don't have vocabulary yet. That's why this is a week-long practice, not a one-time exercise.

---

*Tomorrow: the release practice. You'll delete something.*
