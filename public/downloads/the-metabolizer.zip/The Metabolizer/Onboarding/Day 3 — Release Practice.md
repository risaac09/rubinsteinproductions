# Day 3 — Release Practice

Today you delete something.

Not to prove you can. To feel what deletion feels like in your nervous system. This is a data-collection exercise.

Most people in PKM systems cannot delete. They archive, tag as dormant, "move to someday." This is accumulation wearing a responsible mask. The Metabolizer runs on a different principle: **if it matters, it will return.**

Today you test that principle.

## The Action

Go to your [[Antechamber]]. Look at the seven items from Day 1.

Pick the one with the **least** charge right now. The one that arrived with weight but has quietly gone flat.

Delete it. Not archive. Delete.

Then sit for 10 seconds.

## The Reflection

**What did your body do when you deleted it?**

- Relief?
- Contraction?
- Nothing?
- A flicker of "wait, what if I need it" panic?

Write one sentence. Don't analyze — just name it.

**Body response:**

---

*If it matters, it will return. If it doesn't return, it didn't matter.*

*Tomorrow: the connection.*
