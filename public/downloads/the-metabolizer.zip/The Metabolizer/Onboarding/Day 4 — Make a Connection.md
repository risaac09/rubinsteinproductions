# Day 4 — Make a Connection

Today you metabolize one item. Not file it. Metabolize it.

Filing is putting it where it belongs. Metabolizing is asking *what it's with* — what other idea does it sit next to, argue with, resemble, illuminate?

Connections are the only real output of this system. Notes are residue. Connections are the thing.

## The Action

Go to your [[Antechamber]]. Pick the item with the **most** charge. Not the most interesting — the one your body leans toward.

Ask it two questions:

1. What does this remind me of? (from my life, reading, work, relationships)
2. What does this contradict? (something I believe or practice)

Write 3–5 sentences exploring one of those answers. Not to prove a point. To follow a thread.

Then ask: **does this belong in a Map?** If yes, move it to [[Connections]] with the format:
**[Thing A] + [Thing B] = [What emerged]**

If it's not ready, leave it in the Antechamber with a short note added. The decay clock just reset.

## The Reflection

**Did the connection surprise you?** If the connection felt obvious, you didn't metabolize — you filed. Try again with a different item tomorrow.

---

*Tomorrow: a tension.*
