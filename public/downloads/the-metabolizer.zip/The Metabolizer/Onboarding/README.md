# 7-Day Onboarding

A scaffolded first week. Read one note per day. Do the one action. Answer the one prompt. Close the note.

After Day 7, **delete this folder** (or archive it). The onboarding practices the decay principle — it is not meant to persist.

---

## The Week

1. [[Day 1 — Empty the Antechamber]]
2. [[Day 2 — First Body Check]]
3. [[Day 3 — Release Practice]]
4. [[Day 4 — Make a Connection]]
5. [[Day 5 — Sit With a Tension]]
6. [[Day 6 — First Decay Review]]
7. [[Day 7 — First Threshold]]

---

## The Rule

Don't skip ahead. Don't do two days at once to "catch up." If you miss a day, you miss it. Start where you are. The system does not reward completion — it rewards honesty.
