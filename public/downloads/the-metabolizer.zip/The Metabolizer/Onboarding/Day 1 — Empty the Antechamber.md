# Day 1 — Empty the Antechamber

You are not starting with this vault. You are starting with *everything you were already carrying*.

Before you add a single new thing, empty what's already there — the open browser tabs, the half-written thoughts in Notes, the ideas you've been rehearsing in the shower for six weeks. Not into this vault. Out of your head.

## The Action

Open a blank document — paper, phone, whatever. Write down every unprocessed thing you're carrying right now. No limit, no filter. Keep going until the list stops generating itself.

Then look at the list. Circle no more than **seven** items — the ones with the most charge. The ones your body reacts to.

Those seven go into your [[Antechamber]]. The rest, let go. They were noise you were mistaking for signal.

## The Reflection

**What was on the list that surprised you?** Not the items — the fact that they were there at all.

Write one sentence. Close this note.

---

*Tomorrow: the body check.*
