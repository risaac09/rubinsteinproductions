# Day 6 — First Decay Review

You haven't had time to accumulate decayed items yet — your intake is 5 days old. That's fine. Today is a *practice* decay review.

The point is to build the muscle before you need it.

## The Action

Open [[Decay Review]].

The Dataview query probably won't surface anything yet (items need to be 7+ days dormant). That's okay.

Instead: look at your [[Antechamber]] and ask, for each item:

**If this were 7 days old and I still hadn't processed it, what would I do?**

- Metabolize → move to a Map now
- Release → delete now
- Extend → leave it, honestly noting why

Make one of those three decisions for each remaining item. Act on it today.

## The Reflection

**How many items did you extend?**

If the answer is most of them, you're avoiding the core choice. "Extend" is the escape hatch. Next week, honor the decay more strictly.

**Extended:** __ of __
**Released:** __ of __
**Metabolized:** __ of __

---

*Tomorrow: the first threshold. The only question is what shifted.*
