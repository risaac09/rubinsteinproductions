# Weekly Threshold

**Week of:** {{date:YYYY-MM-DD}}

---

## The One Question

**What shifted this week?**

Not what happened. Not what you accomplished. Not what you read or consumed or produced.

What *changed* — in how you see something, in what you understand, in what you're willing to say, in what you're no longer avoiding?

A threshold is a door you walk through and can't walk back through the same way. Most weeks, the threshold is small. Sometimes it's: "I realized I've been organizing instead of thinking." Sometimes it's: "I finally said the thing I'd been rehearsing."

Name it. One paragraph or one sentence. Both are fine.

**The shift:**


---

## Antechamber Audit

How many items are in your [[Antechamber]] right now?

- [ ] 0–3: You have space. You might be under-intaking — are you avoiding something?
- [ ] 4–5: Healthy range. Keep processing.
- [ ] 6–7: Full. Prioritize metabolization this week before adding.
- [ ] 7+: You broke the rule. Go process now. No judgment, but go.

---

## What Decayed

What did you release this week through the [[Decay Review]]? List anything you let go of.

This is not failure — this is the system working. Not everything that enters your field is yours to carry.

**Released:**
-

---

## What's Building

Look across your Maps ([[Observations]], [[Questions]], [[Connections]], [[Tensions]], [[Practice]]). Is anything accumulating mass? Is a theme emerging across multiple daily practices? Is something trying to become an essay, a project, a conversation?

**Building toward:**


---

## Energy Read

On a scale of 1–10, what's your processing capacity right now?

**Energy:** /10

If below 6: reduce intake this week. Don't add new items to the Antechamber until energy recovers. The system can rest. You should too.
